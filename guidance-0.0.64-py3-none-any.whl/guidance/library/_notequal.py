def notequal(arg1, arg2):
    ''' Check that the arguments are not equal.
    '''
    return arg1 != arg2