def contains(string, substring):
    ''' Check if a string contains a substring.
    '''
    return substring in string