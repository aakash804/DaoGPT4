def greater(arg1, arg2):
    ''' Check if arg1 is greater than arg2.

    Note that this can also be called using `>` as well as `greater`.
    '''

    return arg1 > arg2