def less(arg1, arg2):
    ''' Check if arg1 is less than arg2.

    Note that this can also be called using `<` as well as `less`.
    '''

    return arg1 < arg2